package com.aitravel.publikakun.wisatamitra;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.aitravel.publikakun.wisatamitra.feature.daerah.DaerahFragment;
import com.aitravel.publikakun.wisatamitra.feature.home.FragmentHome;
import com.aitravel.publikakun.wisatamitra.feature.jenis.JenisFragment;
import com.aitravel.publikakun.wisatamitra.feature.manual.ManualFragment;
import com.aitravel.publikakun.wisatamitra.helper.BottomNavigationViewHelper;

public class BottomActivity extends AppCompatActivity {



    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                   fragment = new FragmentHome();
                    break;
                case R.id.navigation_dashboard:
                    fragment = new DaerahFragment();
                    break;
                case R.id.navigation_notifications:
                    fragment = new JenisFragment();
                    break;
                case R.id.navigation_blank:
                    fragment = new ManualFragment();
                    break;
            }
            return loadFragment(fragment);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom);


        loadFragment(new FragmentHome());
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        BottomNavigationViewHelper.disableShiftMode(navigation);
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }


}
