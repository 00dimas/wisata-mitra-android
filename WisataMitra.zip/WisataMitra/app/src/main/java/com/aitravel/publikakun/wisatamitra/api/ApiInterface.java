package com.aitravel.publikakun.wisatamitra.api;

import com.aitravel.publikakun.wisatamitra.model.DataPopuler;
import com.aitravel.publikakun.wisatamitra.model.DetailWisata;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("popular.php")
    Observable<DataPopuler> getDataPopuler();
    @GET("detail.php")
    Observable<DetailWisata> getDetailData(@Query("id") String id);

    @GET("daerah.php")
    Observable<DataPopuler> getDataByDaerah(@Query("id") String id);
    //response with query daerah.php?id=1

    @GET("jenis.php")
    Observable<DataPopuler> getDataByJenis(@Query("id") String id);

    @GET("fasilitas.php")
    Observable<DataPopuler> getDataByFasilitas(@Query("id") String id);

    @GET("akses.php")
    Observable<DataPopuler> getDataByAkses(@Query("id")String id);

    @GET("manual.php")
    Observable<DataPopuler> getDataManual(@Query("id_jarak") String id_jarak,
                                          @Query("id_jenis")String id_jenis,
                                          @Query("id_fasilitas") String id_fasilitas,
                                          @Query("id_akses") String id_akses);
    //id_akses=1&id_fasilitas=1&id_jenis=2
}
