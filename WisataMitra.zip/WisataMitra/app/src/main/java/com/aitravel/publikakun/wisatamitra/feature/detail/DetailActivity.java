package com.aitravel.publikakun.wisatamitra.feature.detail;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.aitravel.publikakun.wisatamitra.R;
import com.aitravel.publikakun.wisatamitra.api.ApiClient;
import com.aitravel.publikakun.wisatamitra.api.ApiInterface;
import com.aitravel.publikakun.wisatamitra.helper.Constants;
import com.aitravel.publikakun.wisatamitra.model.DetailWisata;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class DetailActivity extends AppCompatActivity implements DetailImagesAdapter.ItemListener {
    private RecyclerView recyclerViewImages;
    private DetailImagesAdapter detailImagesAdapter;
    private ImageView imvTitle;
    private ProgressBar progressBar;
    private TextView tvNamaWisata,tvJudul,tvJenis,tvJarak,tvFasilitas,tvBiaya,tvDeskripsi;
    private String id,gambar;
    private Button btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        initLayout();
        id = getIntent().getStringExtra(Constants.idWisata);
        gambar = getIntent().getStringExtra(Constants.gambar);
        getData(id);
//        final String pureBase64Encoded = gambar.substring(gambar.indexOf(",")  + 1);
//        final byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
        Glide.with(this)
                .load(gambar)
                .into(imvTitle);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    private void initLayout()
    {
        imvTitle = findViewById(R.id.img_details);
        tvNamaWisata = findViewById(R.id.tv_nama_wisata);
        tvJudul = findViewById(R.id.tv_judul);
        progressBar = findViewById(R.id.progresbar);
        tvJenis = findViewById(R.id.tv_jenis);
        tvJarak = findViewById(R.id.tv_jarak);
        tvFasilitas = findViewById(R.id.tv_fasilitas);
        tvBiaya = findViewById(R.id.tv_biaya);
        tvDeskripsi = findViewById(R.id.tv_deskripsi);
        btnBack = findViewById(R.id.btn_back);

        recyclerViewImages = findViewById(R.id.rv_gambar);
        recyclerViewImages.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerViewImages.setNestedScrollingEnabled(false);
    }
    private void getData(String id)
    {
        ApiClient.getClient().create(ApiInterface.class).getDetailData(id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DetailWisata>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(DetailWisata detailWisata) {
                        tvNamaWisata.setText(detailWisata.getData().getContent().getNamaWisata());
                        tvJudul.setText(detailWisata.getData().getContent().getJudul());
                        tvJenis.setText(detailWisata.getData().getContent().getJenis());
                        tvJarak.setText(detailWisata.getData().getContent().getJarak());
                        tvFasilitas.setText(detailWisata.getData().getContent().getFasilitas());
                        tvBiaya.setText(detailWisata.getData().getContent().getBiayaTransportasi());
                        tvDeskripsi.setText(detailWisata.getData().getContent().getDeskripsi());

                        detailImagesAdapter = new DetailImagesAdapter(DetailActivity.this,detailWisata.getData().getContent().getGambar(),DetailActivity.this);
                        recyclerViewImages.setAdapter(detailImagesAdapter);
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
    }

    @Override
    public void onImageClick(List<String> gambar) {
        Intent intent = new Intent(DetailActivity.this,GaleryActivity.class);
        List<String> listGambar = new ArrayList<>();
        for (int i=0; i<gambar.size();i++)
        {
            listGambar.add(gambar.get(i));
        }
        intent.putStringArrayListExtra(Constants.listGambar, (ArrayList<String>) listGambar);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
