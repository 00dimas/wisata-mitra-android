package com.aitravel.publikakun.wisatamitra.feature.detail;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.aitravel.publikakun.wisatamitra.R;

import java.util.List;

public class DetailImagesAdapter extends RecyclerView.Adapter<DetailImagesAdapter.ViewHolder> {
    private Context context;
    private List<String> gambar;
    private ItemListener itemListener;

    public DetailImagesAdapter(Context context, List<String> gambar, ItemListener itemListener) {
        this.context = context;
        this.gambar = gambar;
        this.itemListener = itemListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.rv_galery,viewGroup,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        if (viewHolder instanceof DetailImagesAdapter.ViewHolder)
        {
            final String image = gambar.get(i);
//            final String pureBase64Encoded = image.substring(image.indexOf(",")  + 1);
//            final byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
            Glide.with(context)
                    .load(image)
                    .into(viewHolder.imageView);
            viewHolder.rv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    itemListener.onImageClick(gambar);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return gambar.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout rv;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_gallery);
            rv = itemView.findViewById(R.id.rv_galery);
        }
    }
    public interface ItemListener{
        void onImageClick(List<String> gambar);
    }
}
