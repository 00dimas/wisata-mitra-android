package com.aitravel.publikakun.wisatamitra.feature.detail;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.aitravel.publikakun.wisatamitra.R;
import com.aitravel.publikakun.wisatamitra.helper.Constants;
import com.aitravel.publikakun.wisatamitra.helper.ViewPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class GaleryActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private ViewPagerAdapter viewPagerAdapter;
    private ImageView btnBack;
    private List<String> listGambar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_galery);
        viewPager = findViewById(R.id.imv_gambar);
        btnBack = findViewById(R.id.btn_back);
        Log.d(GaleryActivity.class.getSimpleName(), "onCreate: ");

        listGambar = getIntent().getStringArrayListExtra(Constants.listGambar);
        Log.d(GaleryActivity.class.getSimpleName(), "LOGV onCreate: "+listGambar.toString());

        viewPagerAdapter = new ViewPagerAdapter(GaleryActivity.this, (ArrayList<String>) listGambar);
        viewPager.setAdapter(viewPagerAdapter);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
