package com.aitravel.publikakun.wisatamitra.feature.home;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.aitravel.publikakun.wisatamitra.R;
import com.aitravel.publikakun.wisatamitra.api.ApiClient;
import com.aitravel.publikakun.wisatamitra.api.ApiInterface;
import com.aitravel.publikakun.wisatamitra.feature.detail.DetailActivity;
import com.aitravel.publikakun.wisatamitra.helper.Constants;
import com.aitravel.publikakun.wisatamitra.model.DataPopuler;
import com.aitravel.publikakun.wisatamitra.model.ListWisata;

import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FragmentHome extends Fragment implements HomeAdapter.ItemListener {
    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private HomePresenter presenter;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private HomeAdapter homeAdapter;
    private List<ListWisata> listWisatas;
    private ApiInterface apiInterface;


    public FragmentHome() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rv_home);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        progressBar = view.findViewById(R.id.progresbar);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        RecyclerView.LayoutManager rvLiLayoutManager = layoutManager;
        recyclerView.setLayoutManager(rvLiLayoutManager);
        recyclerView.setNestedScrollingEnabled(false);
        getData();

    }
    private void getData()
    {
        ApiClient.getClient().create(ApiInterface.class).getDataPopuler()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DataPopuler>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(DataPopuler dataPopuler) {
                        homeAdapter = new HomeAdapter(getActivity(),dataPopuler.getData().getList_wisata(),FragmentHome.this);
                        recyclerView.setAdapter(homeAdapter);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
    }


    @Override
    public void onItemClick(ListWisata listWisata) {
        Intent intent = new Intent(getActivity(),DetailActivity.class);
        intent.putExtra(Constants.idWisata,listWisata.getId());
        intent.putExtra(Constants.gambar,listWisata.getGambar().get(0));
        startActivity(intent);
    }
}
