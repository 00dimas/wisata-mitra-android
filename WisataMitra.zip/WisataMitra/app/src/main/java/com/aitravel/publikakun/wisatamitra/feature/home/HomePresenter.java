package com.aitravel.publikakun.wisatamitra.feature.home;

import com.aitravel.publikakun.wisatamitra.api.ApiClient;
import com.aitravel.publikakun.wisatamitra.api.ApiInterface;
import com.aitravel.publikakun.wisatamitra.model.DataPopuler;

import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class HomePresenter {
    private HomeView view;
    private CompositeDisposable compositeDisposable;

    public HomePresenter(HomeView view, CompositeDisposable compositeDisposable) {
        this.view = view;
        this.compositeDisposable = compositeDisposable;
    }
    public void getListDataWisata()
    {
        ApiClient.getClient().create(ApiInterface.class).getDataPopuler()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DataPopuler>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(DataPopuler dataPopuler) {
                        view.onGetLoadData(dataPopuler.getData().getList_wisata());
                    }

                    @Override
                    public void onError(Throwable e) {
                        view.onError(e.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        view.onProgresBarSuccess();
                    }
                });
    }

}
