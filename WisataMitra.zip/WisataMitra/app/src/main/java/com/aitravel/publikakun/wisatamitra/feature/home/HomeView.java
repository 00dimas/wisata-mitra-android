package com.aitravel.publikakun.wisatamitra.feature.home;

import com.aitravel.publikakun.wisatamitra.model.ListWisata;

import java.util.List;

public interface HomeView {
    void onGetLoadData(List<ListWisata> wisatas);
    void onError(String e);
    void onProgresBarSuccess();
}
