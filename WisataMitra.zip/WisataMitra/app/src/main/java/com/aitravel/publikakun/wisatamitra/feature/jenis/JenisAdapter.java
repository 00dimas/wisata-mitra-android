package com.aitravel.publikakun.wisatamitra.feature.jenis;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.aitravel.publikakun.wisatamitra.R;
import com.aitravel.publikakun.wisatamitra.model.ListWisata;

import java.util.List;

public class JenisAdapter extends RecyclerView.Adapter<JenisAdapter.ViewHolder> {
    private Context context;
    private List<ListWisata> listWisatas;
    private ItemListener itemListener;

    public JenisAdapter(Context context, List<ListWisata> listWisatas, ItemListener itemListener) {
        this.context = context;
        this.listWisatas = listWisatas;
        this.itemListener = itemListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.rv_content,viewGroup,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        if (viewHolder instanceof JenisAdapter.ViewHolder)
        {
            final ListWisata listWisata = listWisatas.get(i);
            viewHolder.itemJudul.setText(listWisata.getJudul());
            viewHolder.itemJenis.setText(listWisata.getJenis());
//            final String pureBase64Encoded = listWisata.getGambar().substring(listWisata.getGambar().indexOf(",")  + 1);
//            final byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
            Glide.with(context)
                    .load(listWisata.getGambar().get(0))
                    .into(viewHolder.itemGambar);
            viewHolder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    itemListener.onItemListener(listWisata);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listWisatas.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ConstraintLayout item;
        private ImageView itemGambar;
        private TextView itemJudul,itemJenis;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            item = itemView.findViewById(R.id.wisata_item_id);
            itemGambar = itemView.findViewById(R.id.imv_place);
            itemJenis=itemView.findViewById(R.id.tv_jenis);
            itemJudul=itemView.findViewById(R.id.tv_judul);
        }
    }
    public interface ItemListener{
        void onItemListener(ListWisata list);
    }
}
