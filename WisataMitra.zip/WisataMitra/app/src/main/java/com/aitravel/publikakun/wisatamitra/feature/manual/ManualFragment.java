package com.aitravel.publikakun.wisatamitra.feature.manual;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aitravel.publikakun.wisatamitra.R;
import com.aitravel.publikakun.wisatamitra.api.ApiClient;
import com.aitravel.publikakun.wisatamitra.api.ApiInterface;
import com.aitravel.publikakun.wisatamitra.feature.detail.DetailActivity;
import com.aitravel.publikakun.wisatamitra.feature.jenis.JenisAdapter;
import com.aitravel.publikakun.wisatamitra.helper.Constants;
import com.aitravel.publikakun.wisatamitra.model.DataPopuler;
import com.aitravel.publikakun.wisatamitra.model.ListWisata;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class ManualFragment extends Fragment implements JenisAdapter.ItemListener {

    private Spinner spinnerFasilitas,spinnerAkses;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private JenisAdapter adapter;
    private String idAkses="1",idFasilitas="1";
    private TextView textView,textView2;
    public ManualFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_manual, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initLayout(view);
        valueSpinnerAkses();
        valueSpinnerFasilitas();
    }

    @Override
    public void onItemListener(ListWisata list) {
        Intent intent = new Intent(getActivity(),DetailActivity.class);
        intent.putExtra(Constants.idWisata,list.getId());
        intent.putExtra(Constants.gambar,list.getGambar().get(0));
        startActivity(intent);
    }
    private void initLayout(View view){
        spinnerFasilitas = view.findViewById(R.id.spinner_fasilitas);
        spinnerAkses = view.findViewById(R.id.spinner_akses);
        recyclerView = view.findViewById(R.id.rv_manual);
        progressBar = view.findViewById(R.id.progresbar);
        textView = view.findViewById(R.id.text1);
        textView2 = view.findViewById(R.id.text2);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        RecyclerView.LayoutManager rvLiLayoutManager = layoutManager;
        recyclerView.setLayoutManager(rvLiLayoutManager);
        recyclerView.setNestedScrollingEnabled(false);
    }
    private void valueSpinnerAkses()
    {
        String[] akses = new String[]{
                "-- Pilih Akses Wisata --",
                "Kendaraan Bermotor",
                "Jalan Kaki","Perahu"
        };
        final List<String> aksesList = new ArrayList<>(Arrays.asList(akses));
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getActivity(),R.layout.spinner_item,aksesList)
        {
            @Override
            public boolean isEnabled(int position){
                if(position == 0)
                {
                    // Disable the first item from Spinner
                    // First item will be use for hint
                    return false;
                }
                else
                {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if(position == 0){
                    // Set the hint text color gray
                    tv.setTextColor(Color.GRAY);
                }
                else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };

        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        spinnerAkses.setAdapter(spinnerArrayAdapter);

        spinnerAkses.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position==1)
                {
                    idAkses="1";
                    getData(idAkses,idFasilitas);
                }
                else if (position==2)
                {

                    idAkses="2";
                    getData(idAkses,idFasilitas);
                }
                else if (position==3)
                {

                    idAkses="3";
                    getData(idAkses,idFasilitas);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void valueSpinnerFasilitas(){
        String[] fasilitas = new String[]{
                "-- Pilih Fasilitas --", "Rumah Makan", "Penginapan","Alat Diving","Jalan"
        };
        final List<String> fasilitasList = new ArrayList<>(Arrays.asList(fasilitas));
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getActivity(),R.layout.spinner_item,fasilitasList)
        {
            @Override
            public boolean isEnabled(int position){
                if(position == 0)
                {
                    // Disable the first item from Spinner
                    // First item will be use for hint
                    return false;
                }
                else
                {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if(position == 0){
                    // Set the hint text color gray
                    tv.setTextColor(Color.GRAY);
                }
                else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };

        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        spinnerFasilitas.setAdapter(spinnerArrayAdapter);

        spinnerFasilitas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position==1)
                {
                    idFasilitas="1";
                    getData(idAkses,idFasilitas);
                }
                else if (position==2)
                {
                    idFasilitas="2";
                    getData(idAkses,idFasilitas);
                }
                else if (position==3)
                {
                    idFasilitas="3";
                    getData(idAkses,idFasilitas);
                }
                else if (position==4)
                {

                    idFasilitas="4";
                    getData(idAkses,idFasilitas);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    private void getData(String idAkses,String idFasilitas)
    {
        progressBar.setVisibility(View.VISIBLE);
        ApiClient.getClient().create(ApiInterface.class).getDataManual("1","1",idFasilitas,idAkses)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DataPopuler>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(DataPopuler dataPopuler) {
                        adapter = new JenisAdapter(getActivity(),dataPopuler.getData().getList_wisata(),ManualFragment.this);
                        recyclerView.setAdapter(adapter);
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(getActivity(),e.getLocalizedMessage(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {
                        progressBar.setVisibility(View.INVISIBLE);
                        textView.setVisibility(View.INVISIBLE);
                        textView2.setVisibility(View.INVISIBLE);
                    }
                });
    }
}
