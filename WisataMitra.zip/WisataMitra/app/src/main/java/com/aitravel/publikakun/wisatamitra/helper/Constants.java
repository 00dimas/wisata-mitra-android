package com.aitravel.publikakun.wisatamitra.helper;

public class Constants {
    public static final String idWisata = "idWisata";
    public static final String gambar = "gambar";
    public static final String listGambar = "listGambar";
    public static final String sizeListGambar = "sizeListGambar";
}
