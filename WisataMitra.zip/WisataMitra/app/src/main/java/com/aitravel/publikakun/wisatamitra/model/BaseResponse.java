package com.aitravel.publikakun.wisatamitra.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BaseResponse {
    @SerializedName("pilihan_daerah")
    private List<PilihanDaerah> pilihanDaerah = null;
    @SerializedName("pilihan_jenis_wisata")
    private List<PilihanJenisWisata> pilihanJenisWisata = null;
    @SerializedName("pilihan_fasilitas")
    private List<PilihanFasilitas> pilihanFasilitas = null;
    @SerializedName("pilihan_akses")
    private List<PilihanAkses> pilihanAkses = null;
    @SerializedName("counter_status")
    private Integer counterStatus;

    public List<PilihanDaerah> getPilihanDaerah() {
        return pilihanDaerah;
    }

    public void setPilihanDaerah(List<PilihanDaerah> pilihanDaerah) {
        this.pilihanDaerah = pilihanDaerah;
    }

    public List<PilihanJenisWisata> getPilihanJenisWisata() {
        return pilihanJenisWisata;
    }

    public void setPilihanJenisWisata(List<PilihanJenisWisata> pilihanJenisWisata) {
        this.pilihanJenisWisata = pilihanJenisWisata;
    }

    public List<PilihanFasilitas> getPilihanFasilitas() {
        return pilihanFasilitas;
    }

    public void setPilihanFasilitas(List<PilihanFasilitas> pilihanFasilitas) {
        this.pilihanFasilitas = pilihanFasilitas;
    }

    public List<PilihanAkses> getPilihanAkses() {
        return pilihanAkses;
    }

    public void setPilihanAkses(List<PilihanAkses> pilihanAkses) {
        this.pilihanAkses = pilihanAkses;
    }

    public Integer getCounterStatus() {
        return counterStatus;
    }

    public void setCounterStatus(Integer counterStatus) {
        this.counterStatus = counterStatus;
    }
}



