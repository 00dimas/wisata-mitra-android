package com.aitravel.publikakun.wisatamitra.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Content implements Parcelable {
    @SerializedName("judul")
    private String judul;
    @SerializedName("nama_wisata")
    private String namaWisata;
    @SerializedName("gambar")
    private List<String> gambar = null;
    @SerializedName("website")
    private String website;
    @SerializedName("jarak")
    private String jarak;
    @SerializedName("biaya_transportasi")
    private String biayaTransportasi;
    @SerializedName("fasilitas")
    private String fasilitas;
    @SerializedName("akses")
    private String akses;
    @SerializedName("jenis")
    private String jenis;
    @SerializedName("deskripsi")
    private String deskripsi;

    protected Content(Parcel in) {
        judul = in.readString();
        namaWisata = in.readString();
        gambar = in.createStringArrayList();
        website = in.readString();
        jarak = in.readString();
        biayaTransportasi = in.readString();
        fasilitas = in.readString();
        akses = in.readString();
        jenis = in.readString();
        deskripsi = in.readString();
    }

    public static final Creator<Content> CREATOR = new Creator<Content>() {
        @Override
        public Content createFromParcel(Parcel in) {
            return new Content(in);
        }

        @Override
        public Content[] newArray(int size) {
            return new Content[size];
        }
    };

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getNamaWisata() {
        return namaWisata;
    }

    public void setNamaWisata(String namaWisata) {
        this.namaWisata = namaWisata;
    }

    public List<String> getGambar() {
        return gambar;
    }

    public void setGambar(List<String> gambar) {
        this.gambar = gambar;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getJarak() {
        return jarak;
    }

    public void setJarak(String jarak) {
        this.jarak = jarak;
    }

    public String getBiayaTransportasi() {
        return biayaTransportasi;
    }

    public void setBiayaTransportasi(String biayaTransportasi) {
        this.biayaTransportasi = biayaTransportasi;
    }

    public String getFasilitas() {
        return fasilitas;
    }

    public void setFasilitas(String fasilitas) {
        this.fasilitas = fasilitas;
    }

    public String getAkses() {
        return akses;
    }

    public void setAkses(String akses) {
        this.akses = akses;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(judul);
        parcel.writeString(namaWisata);
        parcel.writeStringList(gambar);
        parcel.writeString(website);
        parcel.writeString(jarak);
        parcel.writeString(biayaTransportasi);
        parcel.writeString(fasilitas);
        parcel.writeString(akses);
        parcel.writeString(jenis);
        parcel.writeString(deskripsi);
    }
}
