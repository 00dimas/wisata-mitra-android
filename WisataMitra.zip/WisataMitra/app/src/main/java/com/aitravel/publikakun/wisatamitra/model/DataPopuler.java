package com.aitravel.publikakun.wisatamitra.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DataPopuler  {

    @SerializedName("data")
    private DataPopuler.Data data;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public static class Data extends BaseResponse   {
        @SerializedName("list_wisata")
        private List<ListWisata> list_wisata;


        public List<ListWisata> getList_wisata() {
            return list_wisata;
        }

        public void setList_wisata(List<ListWisata> list_wisata) {
            this.list_wisata = list_wisata;
        }


    }
}
