package com.aitravel.publikakun.wisatamitra.model;

import com.google.gson.annotations.SerializedName;

public class DetailWisata {
    @SerializedName("data")
    private DetailWisata.DataDetail data;

    public DataDetail getData() {
        return data;
    }

    public void setData(DataDetail data) {
        this.data = data;
    }

    public static class DataDetail extends BaseResponse {
        @SerializedName("content")
        private Content content;

        public Content getContent() {
            return content;
        }

        public void setContent(Content content) {
            this.content = content;
        }
    }
}
