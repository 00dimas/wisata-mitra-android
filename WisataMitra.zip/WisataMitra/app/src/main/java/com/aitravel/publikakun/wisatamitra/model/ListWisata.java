package com.aitravel.publikakun.wisatamitra.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ListWisata {
    @SerializedName("id")
    private String id;
    @SerializedName("judul")
    private String judul;
    @SerializedName("gambar")
    private List<String> gambar;
    @SerializedName("jenis")
    private String jenis;
    @SerializedName("0")
    private String _0;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public List<String> getGambar() {
        return gambar;
    }

    public void setGambar(List<String> gambar) {
        this.gambar = gambar;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String get_0() {
        return _0;
    }

    public void set_0(String _0) {
        this._0 = _0;
    }
}
